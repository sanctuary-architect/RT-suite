import json
from rt_suite.types import SuiteReport


def json_report(r: SuiteReport) -> str:
    return r.model_dump_json(indent=2)
