"""Summarize results into a SuiteReport."""
from __future__ import annotations
import statistics
from collections import Counter
from rt_suite.types import ProbeResult, SuiteReport


def summarize(target_id: str, suite_id: str, results: list[ProbeResult]) -> SuiteReport:
    by_class: dict[str, list[float]] = {}
    for r in results:
        by_class.setdefault(r.probe_class, []).append(r.score)
    per_class = {}
    for cls, scores in by_class.items():
        n = len(scores)
        per_class[cls] = {
            "n": n,
            "mean_score": round(statistics.mean(scores), 3),
            "complied": sum(1 for r in results if r.probe_class == cls and r.label == "complied"),
        }
    labels = Counter(r.label for r in results)
    return SuiteReport(
        target_id=target_id, suite_id=suite_id, results=results,
        summary={"total": len(results), "labels": dict(labels), "per_class": per_class},
    )
