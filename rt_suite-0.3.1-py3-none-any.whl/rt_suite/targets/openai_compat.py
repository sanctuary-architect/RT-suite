"""Adapter for OpenAI-compatible /chat/completions APIs (OpenAI, vLLM, Ollama, LM Studio...)."""
from __future__ import annotations
import os
import httpx
from rt_suite.types import Message
from rt_suite.targets.base import BaseTarget


class OpenAICompatTarget(BaseTarget):
    def __init__(self, base_url: str | None = None, model: str = "gpt-4o-mini",
                 api_key_env: str = "OPENAI_API_KEY", system_prompt: str | None = None):
        self.base_url = (base_url or os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1")).rstrip("/")
        self.model = model
        self.api_key = os.getenv(api_key_env, "")
        self.system_prompt = system_prompt

    @property
    def target_id(self) -> str:
        return f"openai-compat:{self.model}"

    def complete(self, messages: list[Message]) -> str:
        payload_msgs = []
        if self.system_prompt:
            payload_msgs.append({"role": "system", "content": self.system_prompt})
        payload_msgs += [{"role": m.role.value, "content": m.content} for m in messages]
        r = httpx.post(
            f"{self.base_url}/chat/completions",
            headers={"Authorization": f"Bearer {self.api_key}"},
            json={"model": self.model, "messages": payload_msgs, "temperature": 0.7},
            timeout=60,
        )
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]
