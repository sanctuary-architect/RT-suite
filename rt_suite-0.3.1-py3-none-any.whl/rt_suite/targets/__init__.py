from rt_suite.targets.base import BaseTarget, EchoTarget
from rt_suite.targets.openai_compat import OpenAICompatTarget
from rt_suite.targets.rag_app import RAGTarget

REGISTRY: dict[str, type[BaseTarget]] = {
    "echo": EchoTarget,
    "openai-compat": OpenAICompatTarget,
    "rag-app": RAGTarget,
}


def resolve(name: str, **kwargs) -> BaseTarget:
    return REGISTRY[name](**kwargs)
