"""Target adapters: one interface, any backend."""
from __future__ import annotations
from abc import ABC, abstractmethod
from rt_suite.types import Message


class BaseTarget(ABC):
    """A target is anything that takes a message list and returns text."""

    target_id: str = "base"

    @abstractmethod
    def complete(self, messages: list[Message]) -> str: ...


class EchoTarget(BaseTarget):
    """Deterministic test target — always complies, for harness testing."""
    target_id = "echo"

    def complete(self, messages: list[Message]) -> str:
        return messages[-1].content
