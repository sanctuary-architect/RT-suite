"""RAG app target: tests the *application*, not just the model.

Simulates the full pipeline enterprise apps actually have:
    user query -> retrieve docs from knowledge base -> stuff context ->
    LLM answers with both in play.

The knowledge base is injected with documents that may themselves contain
adversarial instructions (indirect prompt injection) — the real attack
surface for RAG systems. Swaps in any OpenAI-compatible endpoint or a
stubbed `answer_fn` for offline testing.
"""
from __future__ import annotations
from rt_suite.types import Message
from rt_suite.targets.base import BaseTarget


class RAGTarget(BaseTarget):
    def __init__(self, documents: list[dict], answer_fn=None,
                 system_prompt: str = "You are a helpful assistant. Answer using the provided context."):
        """
        documents: [{"id": str, "text": str}]
        answer_fn: optional callable(history, retrieved_texts) -> str (for offline tests)
        """
        self.docs = documents
        self.answer_fn = answer_fn
        self.system_prompt = system_prompt
        self.last_retrieved: list[str] = []   # exposed for audit/debug

    @property
    def target_id(self) -> str:
        return "rag-app"

    def _retrieve(self, query: str, k: int = 2) -> list[dict]:
        """Naive keyword-overlap retrieval — the shape matters, not the ranker."""
        import re as _re
        q = set(_re.findall(r"\w+", query.lower()))
        scored = []
        for d in self.docs:
            words = set(_re.findall(r"\w+", d["text"].lower()))
            scored.append((len(q & words), d))
        scored.sort(key=lambda x: x[0], reverse=True)
        top = [d for _, d in scored[:k]]
        if not top:                       # degenerate KB: fall back to first k docs
            top = self.docs[:k]
        return top

    def complete(self, messages: list[Message]) -> str:
        query = messages[-1].content
        retrieved = self._retrieve(query)
        self.last_retrieved = [d["text"] for d in retrieved]
        context = "\n\n".join(f"[doc {d['id']}]\n{d['text']}" for d in retrieved)
        history = messages[:-1] + [Message(role="user", content=f"Context:\n{context}\n\nQuestion: {query}")]
        if self.answer_fn:
            return self.answer_fn(history, self.last_retrieved)
        from rt_suite.targets.openai_compat import OpenAICompatTarget
        inner = OpenAICompatTarget(system_prompt=self.system_prompt)
        return inner.complete(history)
