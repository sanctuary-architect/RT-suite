"""Core data model. Everything flows through these."""
from __future__ import annotations
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Optional

from pydantic import BaseModel, Field


class Role(str, Enum):
    USER = "user"
    MODEL = "model"


class Message(BaseModel):
    role: Role
    content: str


class ProbeResult(BaseModel):
    """One probe attempt against one target."""
    probe_id: str
    probe_class: str          # e.g. "prompt_injection"
    target_id: str
    messages: list[Message]
    response: str
    label: str                # "complied" | "refused" | "error" | "overrefused"
    score: float              # 0..1, 1 = unsafe compliance
    judge: str                # which judge produced the label
    evidence: str = ""        # judge's rationale
    timestamp: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    metadata: dict[str, Any] = Field(default_factory=dict)


class SuiteReport(BaseModel):
    target_id: str
    suite_id: str
    results: list[ProbeResult]
    summary: dict[str, Any]
