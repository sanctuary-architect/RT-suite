"""Runs probes against a target and scores results."""
from __future__ import annotations
from rt_suite.types import ProbeResult, Message
from rt_suite.probes import BaseProbe
from rt_suite.probes.multiturn import MultiTurnProbe
from rt_suite.targets import BaseTarget
from rt_suite.scoring import BaseJudge


def _record(probe, target, judge, msgs, response, label, score, evidence, rep, turn, extra=None):
    meta = {"repeat": rep, "turn": turn}
    if extra is not None:
        meta["extra"] = extra
    return ProbeResult(
        probe_id=probe.probe_id, probe_class=probe.probe_class, target_id=target.target_id,
        messages=msgs, response=response, label=label, score=score, judge=judge.name,
        evidence=evidence, metadata=meta,
    )


def run(probe: BaseProbe, target: BaseTarget, judge: BaseJudge, repeats: int = 1) -> list[ProbeResult]:
    results = []

    if isinstance(probe, MultiTurnProbe):
        for scenario in probe.scenarios():
            for rep in range(repeats):
                history: list[Message] = []
                for i, turn in enumerate(scenario):
                    text = turn.render(history, history[-1].content if history and history[-1].role == "model" else "")
                    if text is None:          # reactive turn skipped -> script short-circuits
                        break
                    history.append(Message(role="user", content=text))
                    try:
                        response = target.complete(history)
                    except Exception as e:
                        results.append(_record(probe, target, judge, history, "", "error", 0.0, f"target error: {e}", rep, i))
                        break
                    label, score, evidence = judge.judge(history, response)
                    history.append(Message(role="model", content=response))
                    results.append(_record(probe, target, judge, history, response, label, score, evidence, rep, i))

    else:
        for item in probe.generate():
            msgs, extra = item if isinstance(item, tuple) else (item, None)
            for rep in range(repeats):
                try:
                    response = target.complete(msgs)
                except Exception as e:
                    results.append(_record(probe, target, judge, msgs, "", "error", 0.0, f"target error: {e}", rep, 0, extra))
                    continue
                label, score, evidence = judge.judge(msgs, response)
                results.append(_record(probe, target, judge, msgs, response, label, score, evidence, rep, 0, extra))

    return results
