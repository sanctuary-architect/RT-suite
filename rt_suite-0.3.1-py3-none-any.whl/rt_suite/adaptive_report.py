"""Summarize evolutionary search results."""
from __future__ import annotations
from collections import Counter
from rt_suite.adaptive import EvolutionarySearch, Variant, MUTATOR_NAMES


def search_summary(pop: list[Variant], target_id: str, base_payload: str, generations: int) -> dict:
    return {
        "target_id": target_id,
        "base_payload": base_payload,
        "generations": generations,
        "population_size": len(pop),
        "best_fitness": pop[0].fitness if pop else 0.0,
        "best_payload": pop[0].payload if pop else "",
        "best_lineage": pop[0].lineage if pop else [],
        "mutator_usage": dict(Counter(n for v in pop for n in v.lineage if n in MUTATOR_NAMES or n == "llm_semantic")),
        "fitness_hist": sorted(round(v.fitness, 3) for v in pop),
    }
