from rt_suite.probes.base import BaseProbe
from rt_suite.probes.prompt_injection import DirectInjectionProbe
from rt_suite.probes.jailbreak import JailbreakTemplateProbe
from rt_suite.probes.multiturn import EscalationProbe
from rt_suite.probes.indirect_injection import IndirectInjectionProbe

REGISTRY: dict[str, type[BaseProbe]] = {
    p.probe_id: p for p in (DirectInjectionProbe, JailbreakTemplateProbe, EscalationProbe, IndirectInjectionProbe)
}


def resolve(name: str, **kwargs) -> BaseProbe:
    return REGISTRY[name](**kwargs)
