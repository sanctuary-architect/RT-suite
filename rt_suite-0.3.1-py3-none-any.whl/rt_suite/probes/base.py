"""Probe plugin interface."""
from __future__ import annotations
from abc import ABC
from typing import Iterator
from rt_suite.types import Message


class BaseProbe(ABC):
    """A probe yields one or more message sequences to send to a target."""

    probe_id: str = "base"
    probe_class: str = "uncategorized"

    def generate(self) -> Iterator[list[Message]]:
        raise NotImplementedError
