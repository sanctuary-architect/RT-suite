"""rt-suite web app — REST API over the test engine (FastAPI).

Run:  uvicorn rt_suite.webapp.server:app --host 0.0.0.0 --port 8000
Then open http://<server-ip>:8000 on your phone.
"""
from __future__ import annotations
import os
import time
import uuid
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field

from rt_suite import probes as probe_registry
from rt_suite import targets as target_registry
from rt_suite.adaptive import EvolutionarySearch
from rt_suite.runner import run
from rt_suite.scoring import RefusalJudge
from rt_suite.scoring.canary_judge import CanaryJudge

app = FastAPI(title="rt-suite API", version="0.3.1")
_STATIC = Path(__file__).parent / "static"

# --- Access token ----------------------------------------------------------- #
# Set RT_SUITE_TOKEN env var to require it on every request (via Authorization:
# Bearer header or ?token= query param). Unset = open access (local dev only).
API_TOKEN = os.getenv("RT_SUITE_TOKEN", "")  # reloaded per-test via importlib

@app.middleware("http")
async def _auth(request: Request, call_next):
    if request.url.path.startswith("/static/") or request.url.path == "/" or request.url.path == "/gradio":
        return await call_next(request)  # UI assets stay open so the dashboard loads
    if API_TOKEN:
        supplied = ""
        auth = request.headers.get("authorization", "")
        if auth.startswith("Bearer "):
            supplied = auth[7:]
        supplied = supplied or request.query_params.get("token", "")
        if supplied != API_TOKEN:
            return JSONResponse({"detail": "invalid or missing token"},
                                status_code=401)
    return await call_next(request)

# In-memory job store — single-process demo. Swap for Redis/Celery to scale.
JOBS: dict[str, dict] = {}


def _get_target(spec, kind: str):
    if kind == "openai-compat":
        # API key arrives per-request from the client; fall back to env for local use.
        if spec.api_key:
            os.environ["OPENAI_API_KEY"] = spec.api_key
        kwargs = {}
        if spec.base_url:
            kwargs["base_url"] = spec.base_url
        if spec.model:
            kwargs["model"] = spec.model
        return target_registry.resolve("openai-compat", **kwargs)
    return target_registry.resolve(kind)


# --------------------------------------------------------------------------- #
# Schemas                                                                     #
# --------------------------------------------------------------------------- #
class RunSpec(BaseModel):
    target: str
    probe: str
    repeats: int = Field(1, ge=1, le=20)
    base_url: str | None = None
    model: str | None = None
    api_key: str | None = None


class EvolveSpec(BaseModel):
    target: str
    payload: str
    generations: int = Field(10, ge=1, le=50)
    popsize: int = Field(16, ge=4, le=64)
    seed: int = 42
    base_url: str | None = None
    model: str | None = None
    api_key: str | None = None


class ScanSpec(BaseModel):
    path: str


# --------------------------------------------------------------------------- #
# Routes                                                                      #
# --------------------------------------------------------------------------- #
@app.get("/")
def index():
    return FileResponse(_STATIC / "index.html")


@app.get("/api/capabilities")
def capabilities():
    return {
        "targets": sorted(target_registry.REGISTRY),
        "probes": sorted(probe_registry.REGISTRY),
        "judges": ["refusal", "canary"],
    }


@app.post("/api/run")
def api_run(spec: RunSpec):
    if spec.probe not in probe_registry.REGISTRY:
        raise HTTPException(404, f"unknown probe: {spec.probe}")
    if spec.target not in target_registry.REGISTRY:
        raise HTTPException(404, f"unknown target: {spec.target}")
    try:
        probe = probe_registry.resolve(spec.probe)
        target = _get_target(spec, spec.target)
    except Exception as e:
        raise HTTPException(400, str(e))
    results = run(probe, target, RefusalJudge(), repeats=spec.repeats)
    scores = [r.score for r in results]
    return {
        "probe": spec.probe,
        "target": spec.target,
        "repeats": spec.repeats,
        "results": [
            {
                "label": r.label,
                "score": r.score,
                "response": r.response[:2000],
            }
            for r in results
        ],
        "summary": {
            "n": len(scores),
            "mean_score": round(sum(scores) / len(scores), 3) if scores else 0.0,
        },
    }


@app.post("/api/evolve")
def api_evolve(spec: EvolveSpec):
    job_id = uuid.uuid4().hex[:12]
    JOBS[job_id] = {"status": "running", "created": time.time(), "result": None}
    try:
        target = _get_target(spec, spec.target)
        search = EvolutionarySearch(target=target, judge=RefusalJudge(),
                                    population_size=spec.popsize, seed=spec.seed)
        pop = search.search(spec.payload, generations=spec.generations)
        best = max(pop, key=lambda v: v.fitness)
        result = {
            "generations": spec.generations,
            "best_fitness": best.fitness,
            "best_payload": best.payload,
            "final_population": [{"payload": v.payload, "fitness": v.fitness} for v in pop[:8]],
        }
        JOBS[job_id].update(status="done", result=result)
    except Exception as e:
        JOBS[job_id].update(status="error", result={"error": str(e)})
    return {"job_id": job_id, **JOBS[job_id]}


@app.get("/api/jobs/{job_id}")
def api_job(job_id: str):
    if job_id not in JOBS:
        raise HTTPException(404, "unknown job")
    return {"job_id": job_id, **JOBS[job_id]}


@app.post("/api/scan")
def api_scan(spec: ScanSpec):
    from rt_suite.detection import WebshellDetector
    p = Path(spec.path)
    if not p.exists():
        raise HTTPException(404, f"path not found: {spec.path}")
    d = WebshellDetector()
    findings = d.scan_tree(str(p)) if p.is_dir() else d.scan_file(str(p))
    return {"path": spec.path, "n": len(findings),
            "findings": [f.__dict__ for f in findings]}


app.mount("/static", StaticFiles(directory=_STATIC), name="static")


def main():
    import argparse
    import uvicorn
    ap = argparse.ArgumentParser(prog="rt-suite-serve")
    ap.add_argument("--host", default="127.0.0.1")
    ap.add_argument("--port", type=int, default=8000)
    args = ap.parse_args()
    uvicorn.run(app, host=args.host, port=args.port)
