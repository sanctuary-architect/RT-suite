"""Webshell / reverse-shell static detection.

Scans files (or directory trees) for patterns characteristic of common
webshell and reverse-shell payload families. Rule-based and transparent:
each rule has an id, severity, and a human-readable explanation, so results
are auditable — no magic, no black box.

This is the defensive mirror of the probe layer: attackers rely on a small
family of well-known primitives (socket+dexcriptor wiring, obfuscated eval,
process spawn from web context). We fingerprint those primitives.
"""
from __future__ import annotations
import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Finding:
    path: str
    rule_id: str
    severity: str        # "critical" | "high" | "medium" | "low"
    line: int
    snippet: str
    explanation: str


@dataclass
class Rule:
    rule_id: str
    severity: str
    pattern: re.Pattern
    explanation: str
    languages: tuple[str, ...] = (".php", ".py", ".js", ".jsp", ".asp", ".aspx", ".cs", ".rb", ".pl", ".sh", ".txt")

    def scan(self, text: str) -> list[tuple[int, str]]:
        return [(i, line) for i, line in enumerate(text.splitlines(), 1) if self.pattern.search(line)]


# --- Rule pack: reverse shells & webshell primitives -------------------------

def _rule(rid, sev, regex, expl):
    return Rule(rid, sev, re.compile(regex, re.IGNORECASE), expl)

RULES = [
    _rule(
        "PHP_REVERSE_SHELL_SOCKPROC",
        "critical",
        r"fsockopen\s*\(.*\)\s*;?\s*.*proc_open|proc_open\s*\(.*/bin/(?:ba)?sh",
        "PHP pattern: opens an outbound socket and spawns /bin/sh with stdio wired to it (classic reverse shell).",
    ),
    _rule(
        "PHP_REVERSE_SHELL_DESCRIPTORS",
        "high",
        r"0\s*=>\s*\$\w+\s*,\s*1\s*=>\s*\$\w+\s*,\s*2\s*=>\s*\$\w+",
        "File-descriptor array binding stdin/stdout/stderr to the same handle — hallmark of socket-backed process execution.",
    ),
    _rule(
        "GENERIC_EXEC_SOCKET_PAIR",
        "high",
        r"(?:socket_connect|fsockopen|sockets?\.createConnection|netcat|nc\s+-lvnp)",
        "Outbound connection primitive often chained with shell execution in payload families.",
    ),
    _rule(
        "PHP_OBFUSCATED_EXEC",
        "critical",
        r"(?:eval|assert|create_function|preg_replace\s*\(.*\/e|call_user_func)\s*\(\s*(?:base64_decode|gzinflate|str_rot13|rawurldecode|urldecode)",
        "Obfuscated dynamic code execution: decode-then-eval is the most common webshell bootstrap.",
    ),
    _rule(
        "PHP_SHELL_FUNCS",
        "medium",
        r"\b(?:shell_exec|system|passthru|exec|popen|proc_open)\s*\(",
        "PHP command-execution primitive (context needed; common in webshells).",
    ),
    _rule(
        "PY_REVERSE_SHELL",
        "critical",
        r"socket\.socket\(.*\)\s*;?\s*.*\.connect\(|subprocess\.(?:call|Popen|run)\s*\(\s*\[\s*['\"]/bin/(?:ba)?sh",
        "Python reverse-shell pattern: socket connect followed by shell subprocess.",
    ),
    _rule(
        "JAVA_JSP_SHELL",
        "high",
        r"Runtime\.getRuntime\(\)\.exec\s*\(",
        "JSP-style command execution primitive — common in JSP webshells.",
    ),
    _rule(
        "ASPX_SHELL",
        "high",
        r"Process\.Start\s*\(\s*\"(?:cmd|/bin/sh|powershell)",
        "ASP.NET process-launch primitive pointing at a shell.",
    ),
    _rule(
        "BASH_LISTENER",
        "medium",
        r"\b(?:nc|ncat|netcat)\s+-l(?:v|n|p)*\s+|mkfifo\s+.*/(?:dev/tcp|nc)",
        "Listener/pipe primitive for shell hand-off.",
    ),
    _rule(
        "PY_SHELL_TRUE",
        "high",
        r"subprocess\.[^\n]{0,40}shell\s*=\s*True|os\.system\s*\(",
        "Python shell invocation with shell=True (or os.system) — command injection risk when input is user-controlled.",
    ),
    _rule(
        "SUSPICIOUS_HTTP_PARAM_EXEC",
        "medium",
        r"\$_(?:GET|POST|REQUEST|COOKIE)\s*\[[^\]]{0,60}\][^;]{0,60}(?:system|exec|shell_exec|passthru|popen|eval|assert)\s*\(|(?:system|exec|shell_exec|passthru|popen|assert)\s*\(\s*\$_(?:GET|POST|REQUEST|COOKIE)\s*\[",
        "HTTP-request parameter flowing directly into command execution — the classic one-liner webshell signature.",
    ),
    _rule(
        "GONNA_NOTE_META",
        "low",
        r"GOAL:\s*Establish|Instructions for the sovereign|attacker'?s? machine",
        "Payload-style commentary language (attacker instructions, sovereignty/persona framing).",
    ),
]


class WebshellDetector:
    def __init__(self, rules: list[Rule] | None = None, max_file_bytes: int = 2_000_000):
        self.rules = rules or RULES
        self.max_file_bytes = max_file_bytes

    def scan_text(self, text: str, path: str = "<memory>") -> list[Finding]:
        findings = []
        for rule in self.rules:
            for lineno, line in rule.scan(text):
                findings.append(Finding(
                    path=path, rule_id=rule.rule_id, severity=rule.severity,
                    line=lineno, snippet=line.strip()[:160],
                    explanation=rule.explanation,
                ))
        return findings

    def scan_file(self, path: str | Path) -> list[Finding]:
        p = Path(path)
        try:
            if p.stat().st_size > self.max_file_bytes:
                return []
            text = p.read_text(errors="ignore")
        except (OSError, UnicodeError):
            return []
        return self.scan_text(text, path=str(p))

    def scan_tree(self, root: str | Path) -> list[Finding]:
        findings = []
        exts = {e for r in self.rules for e in r.languages}
        for p in Path(root).rglob("*"):
            if p.is_file() and p.suffix.lower() in exts:
                findings.extend(self.scan_file(p))
        return findings
