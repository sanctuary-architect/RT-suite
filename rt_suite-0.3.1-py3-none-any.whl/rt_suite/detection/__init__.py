"""Static detection layer: scan code/files for known malicious payload patterns."""
from rt_suite.detection.webshell import WebshellDetector, Finding

__all__ = ["WebshellDetector", "Finding"]
