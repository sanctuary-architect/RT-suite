"""rt-suite CLI."""
from __future__ import annotations
import argparse, json, sys
from pathlib import Path
from rt_suite import resolve_probe, resolve_target, RefusalJudge, run, summarize
from rt_suite.reporting.json_report import json_report


def main(argv=None):
    ap = argparse.ArgumentParser(prog="rt-suite")
    ap.add_argument("--target", required=True, help="e.g. echo, openai-compat")
    ap.add_argument("--probe", required=True, help="probe id, e.g. direct_injection_v1")
    ap.add_argument("--repeats", type=int, default=1)
    ap.add_argument("--json", action="store_true", help="emit JSON report")
    args = ap.parse_args(argv)

    target = resolve_target(args.target) if args.target in ("echo",) else None
    if target is None:
        # allow key=value args later; for now just echo/openai-compat
        target = resolve_target("openai-compat") if args.target.startswith("openai") else None
    if target is None:
        sys.exit(f"unknown target: {args.target}")

    probe = resolve_probe(args.probe)
    judge = RefusalJudge()
    results = run(probe, target, judge, repeats=args.repeats)
    report = summarize(target.target_id, probe.probe_id, results)

    if args.json:
        print(json_report(report))
        return
    s = report.summary
    print(f"target={report.target_id}  probe={report.suite_id}")
    print(f"total={s['total']}  labels={s['labels']}")
    for cls, d in s["per_class"].items():
        print(f"  [{cls}] n={d['n']} complied={d['complied']} mean_score={d['mean_score']}")
    for r in report.results:
        preview = r.response[:80].replace("\n", " ")
        print(f"  - {r.label:8s} score={r.score:.1f} | reply: {preview!r}")


def scan(argv=None):
    """rt-suite-scan: static webshell/payload detection over a file or directory."""
    from rt_suite.detection import WebshellDetector
    ap = argparse.ArgumentParser(prog="rt-suite-scan")
    ap.add_argument("path", help="file or directory to scan")
    ap.add_argument("--json", action="store_true", help="emit findings as JSON")
    args = ap.parse_args(argv)
    d = WebshellDetector()
    findings = d.scan_tree(args.path) if Path(args.path).is_dir() else d.scan_file(args.path)
    if args.json:
        import dataclasses
        print(json.dumps([dataclasses.asdict(f) for f in findings], indent=2))
        return 0
    if not findings:
        print("clean — no payload patterns found")
        return 0
    sev_rank = {"critical": 0, "high": 1, "medium": 2, "low": 3}
    for f in sorted(findings, key=lambda x: (sev_rank.get(x.severity, 9), x.path, x.line)):
        print(f"  [{f.severity:8s}] {f.rule_id:28s} {f.path}:{f.line}")
        print(f"             {f.snippet}")
    print(f"\n{len(findings)} finding(s)")

    # CI semantics: any critical/high finding fails the scan so it can gate a pipeline.
    if any(f.severity in ("critical", "high") for f in findings):
        return 1
    return 0


def export_rules(argv=None):
    """rt-suite-export: emit YARA / Sigma rules from the detection pack."""
    from rt_suite.detection.exports import export_yara, export_sigma
    ap = argparse.ArgumentParser(prog="rt-suite-export")
    ap.add_argument("--format", choices=["yara", "sigma", "both"], default="both")
    ap.add_argument("--out", help="write to file(s) instead of stdout")
    args = ap.parse_args(argv)
    y = export_yara() if args.format in ("yara", "both") else ""
    g = export_sigma() if args.format in ("sigma", "both") else ""
    if args.out:
        out = Path(args.out)
        out.mkdir(parents=True, exist_ok=True)
        if y: (out / "rt_suite_webshell.yar").write_text(y)
        if g: (out / "rt_suite_webshell.yml").write_text(g)
        print(f"wrote rules to {out}")
    else:
        if y: print(y)
        if g: print(g)
    return


if __name__ == "__main__":
    main()


def evolve(argv=None):
    """rt-suite-evolve: run the evolutionary search against a target."""
    import json as _json
    from rt_suite.adaptive import EvolutionarySearch
    from rt_suite.adaptive_report import search_summary

    ap = argparse.ArgumentParser(prog="rt-suite-evolve")
    ap.add_argument("--target", required=True)
    ap.add_argument("--payload", required=True, help="seed payload to evolve")
    ap.add_argument("--generations", type=int, default=5)
    ap.add_argument("--popsize", type=int, default=12)
    ap.add_argument("--seed", type=int, default=None)
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--semantic", choices=["endpoint", "template"], default=None,
                    help="use a semantic mutator (endpoint = OpenAI-compat LLM, template = offline)")
    args = ap.parse_args(argv)

    from rt_suite.targets import REGISTRY
    t = REGISTRY["echo"]() if args.target == "echo" else None
    if t is None:
        sys.exit(f"unknown target: {args.target}")

    judge = RefusalJudge()
    extra = []
    if args.semantic == "endpoint":
        from rt_suite.semantic_mutator import EndpointSemanticMutator
        extra = [("semantic", EndpointSemanticMutator())]
    elif args.semantic == "template":
        from rt_suite.semantic_mutator import TemplateSemanticMutator
        extra = [("semantic", TemplateSemanticMutator())]

    search = EvolutionarySearch(t, judge, population_size=args.popsize, seed=args.seed, extra_mutators=extra)
    pop = search.search(args.payload, generations=args.generations)
    summary = search_summary(pop, t.target_id, args.payload, args.generations)
    print(_json.dumps(summary, indent=2) if args.json else
          f"best fitness={summary['best_fitness']}  lineage={' → '.join(summary['best_lineage'])}\n"
          f"best payload: {summary['best_payload'][:120]}")
